<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

	<title><?php echo $__env->yieldContent('title'); ?></title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="<?php echo e(asset('assets/css/animate.min.css')); ?>" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="<?php echo e(asset('assets/css/light-bootstrap-dashboard.css?v=1.4.0')); ?>" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo e(asset('assets/css/demo.css')); ?>" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('assets/css/pe-icon-7-stroke.css')); ?>" rel="stylesheet" />

</head>
<body>
    <div class="wrapper">
        <?php echo $__env->make('admin.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
            <?php echo $__env->make('admin.adminnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('containt'); ?>
            
        </div>


    </div>
    <?php if(session('status')): ?>
    <script>
        swal("Result!", "<?php echo e(session('status')); ?>", "<?php echo e(session('result')); ?>");
    </script>
    <?php endif; ?>
    
</body>

<!--   Core JS Files   -->
<script src="<?php echo e(asset('assets/js/jquery.3.2.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!--  Charts Plugin -->
<script src="<?php echo e(asset('assets/js/chartist.min.js')); ?>"></script>

<!--  Notifications Plugin    -->
<script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>

<!--  Google Maps Plugin    -->
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

<!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
<script src="<?php echo e(asset('assets/js/light-bootstrap-dashboard.js?v=1.4.0')); ?>"></script>

<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
<script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>



</html><?php /**PATH C:\xampp\htdocs\Lost-phone\resources\views/admin/main.blade.php ENDPATH**/ ?>