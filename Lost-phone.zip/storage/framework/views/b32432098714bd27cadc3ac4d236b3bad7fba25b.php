<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('body'); ?>

    <div class="row" style="width: 90%">
      <div class="col-5">
       <div class="container"style="">

            <div class="card text-white" style="margin-top:12%;box-shadow:10px 10px 25px 10px #6f949c;background-color: #20839a; opacity: 90%;padding-bottom:2%;margin-left: 10%">
                <div class="card-head p-2  text-white"><H3 style="text-align: center">Search Imei Now</H3></div>
                <div class="card-body" >
                    <form action="<?php echo e(url('serach_phone')); ?>" class="form-imei" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="">IMEI</label>
                        <input type="number" required class="form-control" name="imei" placeholder="TO get Imei In phone Press *#06#" >
                        <?php $__errorArgs = ['imei'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span style="color: #A50808"><bold><?php echo e($message); ?></bold></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            
                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4 my-2">
                                <button class="button" style="vertical-align:middle"><span>Search </span></button>
            
                            </div>
                        </div>
                    </form>
                
            </div>
            </div>
            </div>
      </div>
      <div class="col-7">
        <div class="container"style="margin-top:10%">
            <table style="opacity: 80%;" class="table table-hover table-dark">
                <thead>
                    <tr>
                        <th>OwnerName</th>
                        <th>Imei</th>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>place of theft</th>
                        <th>Date of theft</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(!empty($phone)): ?>
                  
                    <tr>
                        <td><?php echo e($phone->ownername); ?></td>
                        <td><?php echo e($phone->Imei); ?></td>
                        <td><?php echo e($phone->brand); ?></td>
                        <td><?php echo e($phone->model); ?></td>
                        <td><?php echo e($phone->ptheft); ?></td>
                        <td><?php echo e($phone->date); ?></td>
                    </tr>
                  
                    <?php endif; ?>
                    
                </tbody>
              </table>
        </div>
      </div>
    

<?php /**PATH C:\xampp\htdocs\Lost-phone\resources\views/usersBlade/search.blade.php ENDPATH**/ ?>