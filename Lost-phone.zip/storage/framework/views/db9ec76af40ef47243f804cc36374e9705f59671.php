<div class="sidebar" data-color="purple" data-image="assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Creative Tim
                </a>
            </div>

            <ul class="nav">
                <li class="<?php echo e(Request::is('dashboard') ? 'active' : 'null'); ?>">
                    <a href="<?php echo e(url('/dashboard')); ?>">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('user') ? 'active' : 'null'); ?>">
                    <a href="<?php echo e(url('/user')); ?>">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li class="<?php echo e(Request::is('report') ? 'active' : 'null'); ?>">
                    <a href="<?php echo e(url('/report')); ?>">
                        <i class="pe-7s-note2"></i>
                        <p>Report List</p>
                    </a>
                </li>
                
				
            </ul>
    	</div>
    </div><?php /**PATH C:\xampp\htdocs\Lost-phone\resources\views/admin/adminsidebar.blade.php ENDPATH**/ ?>