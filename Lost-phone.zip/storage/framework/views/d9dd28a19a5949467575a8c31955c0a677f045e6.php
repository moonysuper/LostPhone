
<?php $__env->startSection('title','Users'); ?>
<?php $__env->startSection('containt'); ?>

<div class="card">
    <div class="card-header">
        <h4>Users View</h4>
    </div>
    <div class="card-body">
        <?php if(session('status')): ?>
            <script>
                swal("Good job!", "<?php echo e(session('status')); ?>", "success");
            </script>
        <?php endif; ?>
        <table class="col-12  table table-hover">
            <thead style="text-align:center;">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>phone</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody >
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->mobile); ?></td>
                    <td>
                        <a href="<?php echo e(url('/update_user/'.$item->id)); ?>"><button class="btn btn-primary btn-sm">Edit</button></a>
                        <a href="<?php echo e(url('/delete_user/'.$item->id)); ?>"><button class="btn btn-danger btn-sm">Delete</button></a>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lost-phone\resources\views/admin/adminusers.blade.php ENDPATH**/ ?>