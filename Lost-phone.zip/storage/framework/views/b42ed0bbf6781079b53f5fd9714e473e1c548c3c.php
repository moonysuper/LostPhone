<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
<div class="container" style="margin: 7%">
    <div class="row" >
      <div class="col" style="margin-top: 5%;margin-left: 40$">
        <h1 class="text-white" style="font-family:cursive",>Your phone is stolen?</h1>
        <div class="text-white">What bad luck, we are sorry for what happened, you can save data about your phone if someone finds it, a user will contact you or the thief will not benefit from anything</div>
        
        <a class="float-end" href="<?php echo e(url('search')); ?>" style="text-decoration: none;color: inherit;"><button class="button" style="vertical-align:middle"><span>Search</span></button></a> 
      </div>
      <div class="col">
        <img src="<?php echo e(asset('asset/define/bg.svg')); ?>" alt="" height="80%" width="45%" style="margin-left: 50%">
      </div>
        
    </div>
  <?php /**PATH C:\xampp\htdocs\Lost-phone\resources\views/usersBlade/home.blade.php ENDPATH**/ ?>