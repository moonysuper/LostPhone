
@extends('admin.main')
@section('title','DashBorad')
@section('containt')


<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0"/>


<div class="container">

    <div class="row">
        <div class="col-md-4">
            <div style="background-color: rgb(43, 43, 90);opacity: 70%;padding: 30%;display: inline-block;">
                

                    <div style="color: white">
                        <span style="color: white;padding: 10%" class="material-symbols-outlined">
                            account_circle
                        </span> 200
                   
                </div>
            
            </div>
        </div>
        {{-- ########################################### --}}
        <div class="col-md-4">.col-md-4</div>
        {{-- ########################################### --}}
        <div class="col-md-4">.col-md-4</div>
      </div>
    </div>
    
@endsection